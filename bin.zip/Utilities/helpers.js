const repo = require('../Model/Schema');

exports.generateId = async() => {
    const ID = '1';
    return ID
}