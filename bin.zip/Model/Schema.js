const mongoose = require('mongoose');

mongoose
     .connect('mongodb://localhost:27017/techDesk', {
         useNewUrlParser: true,
         useCreateIndex: true,
         useFindAndModify: true,
         useUnifiedTopology: true,
     })
     .then(() => {console.log('Database Connected')});

     const Schema = new mongoose.Schema(
         {
         userId: {
             type: String,
             required: true,
         }
        },
         {
             timestamps: {
                 createdAt:true,
                 updatedAt: true,
             }
            } 
     
     )
     const test = mongoose.model('repo', Schema);

     module.exports = test;