const express = require('express');

const routing = express.Router();
const tracker = require('../Controller/tracker');

routing.post('/tracker', tracker.allDefect);
routing.all('*', tracker.inValid);

module.exports = routing;
