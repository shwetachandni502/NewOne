const repo = require('../Model/Schema');
const Validator = require('../Utilies/validator');
const helper = require('../Utilies/helpers');

exports.addDefect =async(req, res) => {
    try{
        if(Validator.ValidateName(req.body.Logger) && Validator.ValidateCategory(req.body.Category)){
            const Id = await helper.generateDefectId();
            const defect = await repo.create({
                DefectID: Id,
                Logger: req.body.Logger,
                Category: req.body.Category,
                Description: req.body.Description,
            });
            res.status(201).json({
                status: 'Success',
                data: {
                    defect,
                }
            });
        }
        else if(!Validator.ValidateName(req.body.Logger)){
            res.status(400).json({
                status: 'error',
                result: 'Enter Valid Logger details',
            });
        }
        else if(!Validator.ValidateCategory(req.body.Category)){
            res.status(400).json({
                status: 'fail',
                message: err,
            }); 
        }

    }
    catch(error) {

    }
}